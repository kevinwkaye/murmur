MurmurGPT Windows experimental preview
======================================

One VST3 contains both Murmur and Murk. This build comes from the
experimental MurmurGPT branch, not the production main branch.

INSTALL:
1. Unzip this archive.
2. Close your DAW.
3. Back up your currently installed Murmur.vst3.
4. Copy the Murmur.vst3 folder into:
   C:\Program Files\Common Files\VST3\
5. Reopen your DAW and rescan plugins.
6. Use MurmurGPT-standalone.exe if you prefer a standalone test.

IMPORTANT: The internal VST3 identity is unchanged to preserve
DAW compatibility. The preview may replace the existing Murmur
install, rather than appear as a second separate plugin. Keep
your original VST3 backed up and save a copy of important projects.

Changes (ChatGPT): clock reconstruction filtering and fractional
input timing for non-Classic modes; Env micro-loop seam fix.
Changes (Claude, measured against the pedal demos): reverb tails
darken as they decay and keep a pedal-like stereo image; Stretch
grains line up so held notes stop fluttering; low Clock settings
keep the pedal's aliasing grit without fizzy images. See
docs/MurmurGPT_DSP_AUDIT.md. A/B listening against the hardware
is still required, and fidelity is NOT certified.

Source and handover:
https://github.com/kevinwkaye/murmur/tree/MurmurGPT
